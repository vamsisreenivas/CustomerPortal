import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-opportunity-assessment-worth-winning',
  templateUrl: './gsp-opportunity-assessment-worth-winning.component.html',
  styleUrls: ['./gsp-opportunity-assessment-worth-winning.component.scss']
})
export class GspOpportunityAssessmentWorthWinningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
