import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-opportunity-detail-quotes',
  templateUrl: './gsp-opportunity-detail-quotes.component.html',
  styleUrls: ['./gsp-opportunity-detail-quotes.component.scss']
})
export class GspOpportunityDetailQuotesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
