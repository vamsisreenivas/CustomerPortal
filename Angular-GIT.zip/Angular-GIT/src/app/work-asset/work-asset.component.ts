import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work-asset',
  templateUrl: './work-asset.component.html',
  styleUrls: ['./work-asset.component.scss']
})
export class WorkAssetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
