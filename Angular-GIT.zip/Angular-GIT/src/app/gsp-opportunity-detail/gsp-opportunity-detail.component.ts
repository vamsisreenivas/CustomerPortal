import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-opportunity-detail',
  templateUrl: './gsp-opportunity-detail.component.html',
  styleUrls: ['./gsp-opportunity-detail.component.scss']
})
export class GspOpportunityDetailComponent implements OnInit {

  opportunityTab: any;
  quotesTab: any;

  constructor() { }

  ngOnInit() {
  }

}
